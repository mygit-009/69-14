
public class Chopsticks {

}
